from django.apps import AppConfig


class BibliothequeConfig(AppConfig):
    name = 'bibliotheque'
